from .jtvae import JTVAE

__all__ = [
    'JTVAE',
]
