import os

__version__ = '0.1.1'
debug = False
ROOT_DIR = os.path.abspath(os.path.dirname(__file__))
