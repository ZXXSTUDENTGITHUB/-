import torch
print(torch.__version__)
print(torch.cuda.is_available())


from sklearn.feature_selection import mutual_info_regression
import numpy as np

# 构造数据
np.random.seed(0)
X = np.random.rand(1000, 3)
# 让第一个特征与目标值有关
y = X[:, 0] + np.random.rand(1000) * 0.1

# 计算互信息
mi = mutual_info_regression(X, y)

# 输出结果
for i in range(3):
    print(f"Feature {i+1}: Mutual Information = {mi[i]}")