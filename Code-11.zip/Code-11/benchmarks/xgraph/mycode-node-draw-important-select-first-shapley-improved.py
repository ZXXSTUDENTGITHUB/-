import os
import random
import operator
import torch
import hydra
from omegaconf import OmegaConf
from benchmarks.xgraph.utils import check_dir
from benchmarks.xgraph.gnnNets import get_gnnNets
from benchmarks.xgraph.dataset import get_dataset, get_dataloader
from torch_geometric.utils import add_self_loops, add_remaining_self_loops
from tqdm import tqdm
from torch_geometric.data import Batch, Data
from torch_geometric.utils import remove_self_loops, to_networkx
import copy
import networkx as nx
from NodeUtils import PlotUtils, getACC, GnnNetsNC2valueFunc, __subgraph__, get_reward_func
from tkinter import _flatten
from matplotlib import pyplot as plt

IS_FRESH = False
IS_DELETE_MAX_DEGREE = False


@hydra.main(config_path="config", config_name="config")
def pipeline(config):
    config.models.gnn_saving_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'checkpoints')
    config.explainers.explanation_result_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results')
    config.models.param = config.models.param[config.datasets.dataset_name]
    config.explainers.param = config.explainers.param[config.datasets.dataset_name]
    config.explainers.explanation_result_dir = '/data/Tian/DIG-8-2/benchmarks/xgraph/mycode/results-impove-shpaley'
    print(OmegaConf.to_yaml(config))

    if torch.cuda.is_available():
        device = torch.device('cuda', index=config.device_id)
        torch.cuda.set_device(config.device_id)
    else:
        device = torch.device('cpu')
    # dataset表示存储的全部数据，包含需要的各种信息
    dataset = get_dataset(config.datasets.dataset_root,
                          config.datasets.dataset_name)

    # x表示图中的节点信息，y代表图的个数
    dataset.data.x = dataset.data.x.float()
    dataset.data.y = dataset.data.y.squeeze().long()

    if config.explainers.param.subgraph_building_method == 'split':
        config.models.param.add_self_loop = False

    # 导入一个没有训练的模型，搭好架子，
    model = get_gnnNets(input_dim=dataset.num_node_features,
                        output_dim=dataset.num_classes,
                        model_config=config.models)
    # 导入模型训练好的参数，训练好的参数用文件存储
    state_dict = torch.load(os.path.join(config.models.gnn_saving_dir,
                                         config.datasets.dataset_name,
                                         f"{config.models.gnn_name}_"
                                         f"{len(config.models.param.gnn_latent_dim)}l_best.pth"))['net']
    # 给模型赋值训练好的参数，库函数
    model.load_state_dict(state_dict)
    model.to(device)
    model.eval()

    # 结果保存路径，数据集，方法名字等
    explanation_saving_dir = os.path.join(config.explainers.explanation_result_dir,
                                          config.datasets.dataset_name,
                                          config.models.gnn_name,
                                          config.explainers.param.reward_method)
    check_dir(explanation_saving_dir)  # 创建文件夹

    # 用于画图
    plot_utils = PlotUtils(dataset_name=config.datasets.dataset_name, is_show=False)

    # 节点层面的解释
    data = dataset.data
    data.to(device)
    # data.edge_index = add_self_loops(data.edge_index, num_nodes=data.num_nodes)[0]  # 添加自环
    # data.edge_index = add_remaining_self_loops(data.edge_index, num_nodes=data.num_nodes)[0]

    # node_indices,要进行预测的节点编号
    node_indices = torch.where(dataset[0].test_mask * dataset[0].y != 0)[0].tolist()
    # 全部的预测结果
    predictions = model(data).argmax(-1)

    originalGraph_prop = 0
    subGraph_prop = 0

    Fidelity = 0
    Fidelity_inv = 0
    Sparsity = 0
    delete_important_node_1 = 0
    delete_unimportant_node_1 = 0
    delete_important_node_2 = 0
    delete_unimportant_node_2 = 0
    delete_important_node_3 = 0
    delete_unimportant_node_3 = 0
    # print(explanation_saving_dir)
    check_dir(explanation_saving_dir)
    true_num = 0
    for node_idx in node_indices:
        print(len(node_indices))
        data.to(device)
        # saved_MCTSInfo_list = None
        x = data.x  # 700个节点的向量表示，10维，全为1
        edge_index = data.edge_index  # 原图的边
        label = predictions[node_idx].item()  # 模型预测的节点的分类（ba_shapes是4分类）

        # if data.y[node_idx] == label:
        #     true_num += 1
        '''节点分类，只考虑目标节点的num_hops（3）阶邻居，将他看作新的原图，进行寻找子图
        图：graph   图的节点数：num_nodes    目标节点：new_node_idx
        '''
        graph_data = Data(x=x, edge_index=remove_self_loops(edge_index)[0])
        graph = to_networkx(graph_data, to_undirected=True)
        ori_graph = copy.copy(graph)
        x, edge_index, subset, edge_mask, kwargs = \
            __subgraph__(node_idx=node_idx, x=x, edge_index=edge_index, num_hops=3)  # num_hops，3表示目标节点的三阶邻居
        subset_data = Batch.from_data_list([Data(x=x, edge_index=edge_index)])  # 重新生成的图data
        subset_graph = ori_graph.subgraph(subset.tolist())  # 重新生成的graph
        mapping = {int(v): k for k, v in enumerate(subset)}
        subset_graph = nx.relabel_nodes(subset_graph, mapping)  # 对子图的编号进行重新映射
        subset_adj = subset_graph.adj  # 得到邻接矩阵adj，后面增加节点使用
        new_node_idx = torch.where(subset == node_idx)[0].item()
        num_nodes = subset_graph.number_of_nodes()  # 节点数目
        subset_probs = model(subset_data.x, subset_data.edge_index).squeeze().softmax(dim=-1)

        if data.y[node_idx] == subset_probs[new_node_idx].argmax(-1).item():
            true_num += 1

        # 传入一个value_func方法，返回的是一个Shapley值计算方法的方法（需要传入指定的shapley参数）入GCN模型，真实的标签
        value_func = GnnNetsNC2valueFunc(model, node_idx=new_node_idx, target_class=label)
        # 计算子图的一个得分，通过Shapley方式,使用方式：score_func(coalition, data)
        if subset_data.num_nodes > 15:
            print(node_idx, ' my')
            # 传入一个value_func方法，返回的是一个Shapley值计算方法的方法（需要传入指定的shapley参数）入GCN模型，真实的标签
            score_func = get_reward_func(value_func=value_func,
                                         node_idx=new_node_idx,
                                         reward_method=config.explainers.param.get('reward_method'),
                                         subgraph_building_method=config.explainers.param.get(
                                             'subgraph_building_method'))  # 计算子图的一个得分，通过Shapley方式,使用方式：score_func(coalition, data)
        else:
            # 当节点数非常少的时候直接用原始的l_shapley方式
            print(node_idx, ' l_shapley')
            score_func = get_reward_func(value_func=value_func,
                                         reward_method='l_shapley',
                                         node_idx=new_node_idx,
                                         subgraph_building_method=config.explainers.param.get(
                                             'subgraph_building_method'))
        # score = score_func(list(subset_graph.nodes), subset_data)
        '''防止忠诚度很小'''
        one_Fidelity = 0
        time_fidlity = 0
        coalition = []
        select_max = -1
        select_max_coalition = []

        # 对节点的重要性排序，只取40%的节点作为第一个节点，最大不超过6
        graph_nodes = list(subset_graph.nodes)
        score_dict = dict()
        for item in graph_nodes:
            score = score_func([item], subset_data)
            score_dict[item] = score
        score_dict = dict(sorted(score_dict.items(), key=lambda x: x[1], reverse=True))
        score_dict_keys = list(score_dict.keys())

        if int(len(score_dict_keys) * 0.4 + 1) <= 8:
            score_dict_keys = score_dict_keys[:int(len(score_dict_keys) * 0.4 + 1)]
            score_dict_keys_num = len(score_dict_keys)
        else:
            score_dict_keys = score_dict_keys[:8]
            score_dict_keys_num = len(score_dict_keys)

        final_score = -1
        while one_Fidelity < 0.9:
            time_fidlity += 1
            if time_fidlity > score_dict_keys_num * 4:
                break

            # 得到第一个节点
            coalition = [score_dict_keys[time_fidlity % score_dict_keys_num]]
            if config.datasets.dataset_name in ['ba_2motifs']:
                MIN_node = 4
                if time_fidlity >= score_dict_keys_num:
                    MIN_node = 5
                if time_fidlity >= score_dict_keys_num * 2:
                    MIN_node = 6
                if time_fidlity >= score_dict_keys_num * 3:
                    MIN_node = 7
                if time_fidlity >= score_dict_keys_num * 3 and one_Fidelity_final < 0.1:
                    MIN_node = int(subset_data.num_nodes * 0.9)
            else:
                MIN_node = 3
                if time_fidlity >= score_dict_keys_num:
                    MIN_node = 4
                if time_fidlity >= score_dict_keys_num * 2:
                    MIN_node = 5
                if time_fidlity >= score_dict_keys_num * 3:
                    MIN_node = 6
                if time_fidlity >= score_dict_keys_num * 3 and one_Fidelity_final < 0.1:
                    MIN_node = int(subset_data.num_nodes * 0.9)

            while (True):
                adj_nodes = list()
                [adj_nodes.append(list(subset_adj._atlas[i].keys())) for i in coalition]
                adj_nodes = list(set(_flatten(adj_nodes)))
                for node in coalition:
                    if node in adj_nodes:
                        adj_nodes.remove(node)

                maxScore = -1
                tmp = []
                for node in adj_nodes:
                    tmp.clear()
                    tempCoalition = coalition.copy()
                    tempCoalition.append(node)
                    score = score_func(tempCoalition, subset_data)
                    if score > maxScore:
                        maxScore = score
                        tmp = tempCoalition
                if len(tmp) == 0:
                    coalition.append(adj_nodes[0])
                else:
                    coalition = tmp

                sub_probs = getACC(coalition=coalition, data=subset_data, graph=subset_graph, model=model)
                # print(sub_probs[new_node_idx][label].item())
                if subset_probs[new_node_idx][label] <= sub_probs[new_node_idx][label] + 0.05 and \
                        len(coalition) >= MIN_node or len(coalition) == subset_data.num_nodes:
                    against_coalition = []
                    for node in subset_graph.nodes:
                        if node not in coalition:
                            against_coalition.append(node)
                    against_coalition_probs = getACC(coalition=against_coalition, data=subset_data, graph=subset_graph,
                                                     model=model)
                    # 原图的预测值 - 不要要节点的预测值
                    one_Fidelity = subset_probs[new_node_idx][label].item() - \
                                   against_coalition_probs[new_node_idx][label].item()

                    # 原图的预测值 - 重要节点的预测值
                    one_Fidelity_inv = subset_probs[new_node_idx][label].item() - \
                                       sub_probs[new_node_idx][label].item()
                    one_Sparsity = len(coalition) / subset_data.num_nodes

                    score = score_func(coalition, subset_data)
                    if score > final_score:
                        one_Fidelity_final = one_Fidelity
                        one_Fidelity_inv_final = one_Fidelity_inv
                        one_Sparsity_final = one_Sparsity
                        select_max_coalition = coalition.copy()
                        final_score = score
                    print('one_Fidelity:', round(one_Fidelity, 4), ",score:", round(score, 4), coalition)
                    break
                # 画图
        print("one_Fidelity_final:", round(one_Fidelity_final, 4),
              ",final_score:", round(final_score, 4),
              select_max_coalition)
        Fidelity += one_Fidelity_final
        Fidelity_inv += one_Fidelity_inv_final
        Sparsity += one_Sparsity_final
        coalition = select_max_coalition.copy()

        y = data.y
        subgraph_y = y[subset].to('cpu')
        subgraph_y = torch.tensor([subgraph_y[node].item()
                                   for node in subset_graph.nodes()])

        # title_sentence = f'fide: {one_Fidelity_final:.3f}, ' \
        #                  f'fide_inv: {one_Fidelity_inv_final:.3f}, ' \
        #                  f'spar: {1 - one_Sparsity_final:.3f}'
        title_sentence = ""

        predict_true = 'True' if predictions[node_idx].item() == data.y[node_idx].item() else "False"
        one_Sparsity_final = format(one_Sparsity_final, '.4f')
        one_Fidelity_final = format(one_Fidelity_final, '.4f')
        one_Fidelity_inv_final = format(one_Fidelity_inv_final, '.4f')
        path = os.path.join(explanation_saving_dir, f'example_{node_idx}_'
                                                    f'prediction_{label}_'
                                                    f'label_{data.y[node_idx].item()}_'
                                                    f'pred_{predict_true}'
                                                    f'sparsity_{one_Sparsity_final}_'
                                                    f'Fidelity_{one_Fidelity_final}_'
                                                    f'Fidelity+_{one_Fidelity_inv_final}.png'
                            )

        node_plot(dataname=config.datasets.dataset_name,
                  plot_utils=plot_utils,
                  ori_graph=subset_graph,
                  coalition=coalition, new_node_idx=new_node_idx,
                  title_sentence=title_sentence,
                  subgraph_y=subgraph_y,
                  vis_name=path)

        '''对找出的节点进行重要性排序'''
        coalition_nums = len(coalition)
        res_coalition = coalition.copy()
        # print(res_coalition)
        dict_coalition = dict()  # 每个节点出现的次数保存在字典中
        for node in res_coalition:
            dict_coalition[node] = 0

        coalition.clear()

        kkk = 0
        times = 0  # 加入噪声的次数
        while times < 20:
            times += 1
            copy_data = subset_data.clone()
            random_coaltion = list()
            while len(random_coaltion) != 2:
                tmp = random.randint(0, copy_data.num_nodes - 1)
                if random_coaltion.__contains__(tmp):
                    continue
                random_coaltion.append(tmp)
            # print("random_coaltion:", random_coaltion)
            copy_data.x[random_coaltion, :] = 0
            maxScore = -1
            coalition = []
            if IS_DELETE_MAX_DEGREE:
                node_degree_list = sorted(subset_graph.degree, key=lambda x: x[1], reverse=True)
                graph_nodes = list(subset_graph.nodes)

                if len(graph_nodes) > 3:  # 删除度最大的k个节点
                    for k in range(3):
                        graph_nodes.remove(node_degree_list[k][0])
                tempCoalition = []
                for item in graph_nodes:
                    tempCoalition.clear()  # 选择第一个节点
                    tempCoalition.append(item)
                    score = score_func(tempCoalition, subset_data)
                    if score > maxScore:
                        maxScore = score
                        coalition.clear()
                        coalition = tempCoalition.copy()
            else:
                for item in range(subset_data.num_nodes):
                    tempCoalition = []
                    tempCoalition.append(item)
                    score = score_func(tempCoalition, subset_data)  # score_func计算shapley值得分
                    if score > maxScore:
                        maxScore = score
                        coalition = tempCoalition  # coalition存储贡献最大的节点
            while (True):  # 直到满足条件则停止
                # 得到当前节点的邻居节点，去除重复节点和已经选定的节点，返回的是一维列表：adj_nodes
                adj_nodes = list()
                [adj_nodes.append(list(subset_adj._atlas[i].keys())) for i in coalition]
                adj_nodes = list(set(_flatten(adj_nodes)))
                for node in coalition:
                    if node in adj_nodes:
                        adj_nodes.remove(node)

                # 如果coaltion没有邻居节点，则结束
                if len(adj_nodes) == 0:
                    for node in coalition:
                        if dict_coalition.__contains__(node):
                            dict_coalition[node] = dict_coalition.get(node) + 1
                    break

                maxScore = -1
                tmp = []
                for node in adj_nodes:
                    tmp.clear()
                    tempCoalition = coalition.copy()
                    tempCoalition.append(node)
                    score = score_func(tempCoalition, copy_data)
                    if score > maxScore:
                        maxScore = score
                        tmp = tempCoalition
                if len(tmp) == 0:
                    coalition.append(adj_nodes[0])
                else:
                    coalition = tmp
                sub_probs = getACC(coalition=coalition, data=copy_data, graph=subset_graph, model=model)
                # if subset_probs[new_node_idx][label] <= sub_probs[new_node_idx][label] + 0.20 and len(coalition) >= 3:
                # if len(coalition) >= coalition_nums * 0.6 and len(coalition) >= 2:
                # if len(coalition) >= 4:   Final
                kkk = 3
                if len(coalition) >= kkk:
                    for node in coalition:
                        if dict_coalition.__contains__(node):
                            dict_coalition[node] = dict_coalition.get(node) + 1
                    break

        path = os.path.join(explanation_saving_dir, f'example_{node_idx}_'
                                                    f'prediction_{label}_'
                                                    f'label_{data.y[node_idx].item()}_'
                                                    f'pred_{predict_true}_important.png')
        # 按重要性进行排序后的节点进行画图
        print(dict_coalition)
        plot_important_node(dataname=config.datasets.dataset_name,
                            dict_coalition=dict_coalition,
                            path=path,
                            data=subset_data,
                            graph=subset_graph)
        K = 1
        delete_important_nodes_prop, delete_unimportant_nodes_prop = \
            delete_node_prop(dict_coalition=dict_coalition,
                             K=K,
                             data=subset_data,
                             graph=subset_graph,
                             model=model)
        delete_important_node_1 += \
            subset_probs[new_node_idx][label] - delete_important_nodes_prop[new_node_idx][label]
        delete_unimportant_node_1 += \
            subset_probs[new_node_idx][label] - delete_unimportant_nodes_prop[new_node_idx][label]

        K = 2
        delete_important_nodes_prop, delete_unimportant_nodes_prop = \
            delete_node_prop(dict_coalition=dict_coalition,
                             K=K,
                             data=subset_data,
                             graph=subset_graph,
                             model=model)
        delete_important_node_2 += \
            subset_probs[new_node_idx][label] - delete_important_nodes_prop[new_node_idx][label]
        delete_unimportant_node_2 += \
            subset_probs[new_node_idx][label] - delete_unimportant_nodes_prop[new_node_idx][label]

        K = 3
        delete_important_nodes_prop, delete_unimportant_nodes_prop = \
            delete_node_prop(dict_coalition=dict_coalition,
                             K=K,
                             data=subset_data,
                             graph=subset_graph,
                             model=model)
        delete_important_node_3 += \
            subset_probs[new_node_idx][label] - delete_important_nodes_prop[new_node_idx][label]
        delete_unimportant_node_3 += \
            subset_probs[new_node_idx][label] - delete_unimportant_nodes_prop[new_node_idx][label]
    print("kkk", kkk)
    print("Sparsity = %.2f" % (1 - Sparsity / len(node_indices)),
          "Fidelity_inv = %.4f" % (Fidelity_inv / len(node_indices)),
          "Fidelity = %.4f" % (Fidelity / len(node_indices)))

    print("delete ", 1, "nodes", "important:", delete_important_node_1 / len(node_indices),
          " unimportant:", delete_unimportant_node_1 / len(node_indices))
    print("delete ", 2, "nodes", "important:", delete_important_node_2 / len(node_indices),
          " unimportant:", delete_unimportant_node_2 / len(node_indices))
    print("delete ", 3, "nodes", "important:", delete_important_node_3 / len(node_indices),
          " unimportant:", delete_unimportant_node_3 / len(node_indices))

    print(config.datasets.dataset_name, config.explainers.param.get('reward_method'))
    print(true_num / len(node_indices))


def node_plot(dataname, plot_utils, ori_graph, coalition, new_node_idx, title_sentence, subgraph_y, vis_name):
    if dataname in ['ba_shapes', 'tree_cycle', 'tree_grid']:
        plot_utils.plot(ori_graph,
                        coalition,
                        node_idx=new_node_idx,
                        title_sentence=title_sentence,
                        y=subgraph_y,
                        figname=vis_name)


def plot_important_node(dataname, dict_coalition, path, data, graph):
    if dataname in ['ba_shapes', 'tree_cycle', 'tree_grid']:
        # 对原图的子图中的节点进行重要行排序，按值降序排序
        dict_coalition = dict(sorted(dict_coalition.items(), key=lambda x: x[1], reverse=True))
        subgrap_coalition = list(dict_coalition.keys())
        # print(subgrap_coalition)
        pos = nx.kamada_kawai_layout(graph)
        pos_nodelist = {k: v for k, v in pos.items() if k in subgrap_coalition}
        alpha = dict()  # 设置透明度
        for i in graph.nodes:
            alpha[i] = 0

        if dict_coalition.get(subgrap_coalition[0]) != 0:
            for i in subgrap_coalition:
                if dict_coalition.get(subgrap_coalition[0]) == 0:
                    alpha[i] = 0.1
                else:
                    alpha[i] = dict_coalition.get(i) / dict_coalition.get(subgrap_coalition[0])
                if alpha[i] < 0.1:
                    alpha[i] = 0.1  # 透明度最小为0.1
        else:
            for i in range(len(alpha)):
                alpha[i] = 0.1

        alpha_items = list(alpha.values())
        nx.draw_networkx_nodes(graph, pos,  # 先画一圈黑色
                               nodelist=list(graph.nodes()),
                               node_color='#000000',
                               node_size=400)
        nx.draw_networkx_nodes(graph, pos,  # 在画一圈白色
                               nodelist=list(graph.nodes()),
                               node_color='#ffffff',
                               node_size=300)
        nx.draw_networkx_nodes(graph, pos,  # 根据重要性程度排序，叠加掩盖
                               nodelist=list(graph.nodes()),
                               node_color='#ed6618',
                               alpha=alpha_items,
                               node_size=300)
        nx.draw_networkx_edges(graph, pos, width=3, edge_color='gray', arrows=False)  # 先画所有边，gray
        edgelist = [(n_frm, n_to) for (n_frm, n_to) in graph.edges()
                    if n_frm in subgrap_coalition and n_to in subgrap_coalition]

        nx.draw_networkx_edges(graph, pos=pos_nodelist,  # 把子图节点用另外一种边连接起来
                               edgelist=edgelist, width=4,
                               edge_color='#ed6618',
                               alpha=0.5,
                               arrows=False)
        plt.axis('off')
        plt.savefig(path)
        # plt.show()
        plt.close()


def delete_node_prop(dict_coalition, K, data, graph, model):
    # 对原图的子图中的节点进行重要行排序，按值降序排序
    dict_coalition = dict(sorted(dict_coalition.items(), key=lambda x: x[1], reverse=True))
    subgrap_coalition = list(dict_coalition.keys())
    delete_important_nodes = subgrap_coalition[K:]
    delete_important_nodes_prop = getACC(coalition=delete_important_nodes,
                                         data=data,
                                         graph=graph,
                                         model=model)
    delete_unimportant_nodes = subgrap_coalition[:len(subgrap_coalition) - K]
    delete_unimportant_nodes_prop = getACC(coalition=delete_unimportant_nodes,
                                           data=data,
                                           graph=graph,
                                           model=model)
    return delete_important_nodes_prop, delete_unimportant_nodes_prop


if __name__ == '__main__':
    import sys

    sys.argv.append('explainers=mycode')
    pipeline()
