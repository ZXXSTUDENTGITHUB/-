import os
import random
import hydra
import networkx as nx
from matplotlib import pyplot as plt
from omegaconf import OmegaConf
from benchmarks.xgraph.utils import check_dir
from benchmarks.xgraph.gnnNets import get_gnnNets
from benchmarks.xgraph.dataset import get_dataset, get_dataloader
from torch_geometric.utils import add_self_loops, add_remaining_self_loops
from torch_geometric.utils import remove_self_loops
from shapley import *
from tkinter import _flatten
from GraphUtils import getACC, PlotUtils, GnnNetsGC2valueFunc, get_reward_func, reward_func
from dig.xgraph.models import GCN_3l

IS_FRESH = False
IS_DELETE_MAX_DEGREE = False

"""利用SHAP值计算子图对结果的贡献度
   选择贡献程度最高的节点
   子图的预测值好于原图预测值
   选择第一个节点的时候没有特殊处理（去掉度比较高的几个节点）
   没有画图保存
   """


@hydra.main(config_path="config", config_name="config")
def pipeline(config):
    config.models.gnn_saving_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'checkpoints')
    config.explainers.explanation_result_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results')
    config.models.param = config.models.param[config.datasets.dataset_name]
    config.explainers.param = config.explainers.param[config.datasets.dataset_name]
    config.explainers.explanation_result_dir = '/data/Tian/DIG-8-2/benchmarks/xgraph/mycode/results-impove-shpaley'
    print(OmegaConf.to_yaml(config))
    config.models.param.add_self_loop = False

    if torch.cuda.is_available():
        device = torch.device('cuda', index=config.device_id)
        torch.cuda.set_device(config.device_id)
    else:
        device = torch.device('cpu')
    # dataset表示存储的全部数据，包含需要的各种信息
    dataset = get_dataset(config.datasets.dataset_root,
                          config.datasets.dataset_name)

    # x表示图中的节点信息，y代表图的个数
    dataset.data.x = dataset.data.x.float()

    if config.datasets.dataset_name == 'tox21':
        dataset.data.y = dataset.data.y[:, 2].squeeze().long()
    else:
        dataset.data.y = dataset.data.y.squeeze().long()

    if config.models.param.graph_classification:
        dataloader_params = {'batch_size': config.models.param.batch_size,
                             'random_split_flag': config.datasets.random_split_flag,
                             'data_split_ratio': config.datasets.data_split_ratio,
                             'seed': config.datasets.seed}
        loader = get_dataloader(dataset, **dataloader_params)
        test_indices = loader['test'].dataset.indices

    if config.explainers.param.subgraph_building_method == 'split':
        config.models.param.add_self_loop = False

    model = get_gnnNets(input_dim=dataset.num_node_features,
                        output_dim=dataset.num_classes,
                        model_config=config.models)
    state_dict = torch.load(os.path.join(config.models.gnn_saving_dir,
                                         config.datasets.dataset_name,
                                         f"{config.models.gnn_name}_"
                                         f"{len(config.models.param.gnn_latent_dim)}l_best.pth"))['net']
    # 给模型赋值训练好的参数，库函数
    model.load_state_dict(state_dict)
    model.to(device)
    model.eval()

    # 结果保存路径，数据集，方法名字等
    explanation_saving_dir = os.path.join(config.explainers.explanation_result_dir,
                                          config.datasets.dataset_name,
                                          config.models.gnn_name,
                                          config.explainers.param.reward_method)

    check_dir(explanation_saving_dir)  # 创建文件夹

    # 用于画图，分子图
    plot_utils = PlotUtils(dataset_name=config.datasets.dataset_name, is_show=False)

    # 计算忠诚度和稀疏度
    Sparsity = 0
    Fidelity = 0
    Fidelity_inv = 0

    # 验证排序是否准确
    delete_important_node_1 = 0
    delete_unimportant_node_1 = 0
    delete_important_node_2 = 0
    delete_unimportant_node_2 = 0
    delete_important_node_3 = 0
    delete_unimportant_node_3 = 0

    print(len(test_indices))
    True_num = 0

    for i, data in enumerate(dataset[test_indices]):
        data.to(device)  # data存储方式：稀疏矩阵,data是一个图
        # data.edge_index = add_self_loops(data.edge_index, num_nodes=data.num_nodes)[0]  # 对节点添加自环，自身-->自身
        data.edge_index = add_remaining_self_loops(data.edge_index, num_nodes=data.num_nodes)[0]

        data.to(device)
        # 只用预测的结果，因为我们是解释模型
        prediction = model(data).argmax(-1).item()
        # prediction = model(data=Batch.from_data_list([data])).argmax(-1).item()

        label = prediction

        if label == data.y.item():
            True_num += 1

        graph_data = Data(x=data.x, edge_index=remove_self_loops(data.edge_index)[0])  # 去掉自环
        graph = to_networkx(graph_data, to_undirected=True)  # 说明是无向图
        # 得到邻接矩阵adj，后面增加节点使用
        adj = graph.adj

        # 训练出的模型的预测，原图的预测结果
        model_probs = model(data.x, data.edge_index).squeeze().softmax(dim=-1)

        value_func = GnnNetsGC2valueFunc(model, target_class=label)

        # if data.num_nodes >= 15:
        #     print(test_indices[i], '  my')
        #     # 传入一个value_func方法，返回的是一个Shapley值计算方法的方法（需要传入指定的shapley参数）入GCN模型，真实的标签
        #     score_func = get_reward_func(value_func=value_func,
        #                                  reward_method=config.explainers.param.get('reward_method'),
        #                                  subgraph_building_method=config.explainers.param.get(
        #                                      'subgraph_building_method'))  # 计算子图的一个得分，通过Shapley方式,使用方式：score_func(coalition, data)
        # else:
        #     # 当节点数非常少的时候直接用原始的l_shapley方式
        #     print(test_indices[i], '  l_shapley')
        #     score_func = get_reward_func(value_func=value_func,
        #                                  reward_method='l_shapley',
        #                                  subgraph_building_method=config.explainers.param.get(
        #                                      'subgraph_building_method'))

        # 传入一个value_func方法，返回的是一个Shapley值计算方法的方法（需要传入指定的shapley参数）入GCN模型，真实的标签
        score_func_my = get_reward_func(value_func=value_func,
                                        reward_method='my_shapley',
                                        subgraph_building_method=config.explainers.param.get(
                                            'subgraph_building_method'))  # 计算子图的一个得分，通过Shapley方式,使用方式：score_func(coalition, data)

        score_func_l_shapley = get_reward_func(value_func=value_func,
                                               reward_method='l_shapley',
                                               subgraph_building_method=config.explainers.param.get(
                                                   'subgraph_building_method'))

        TT = 5
        print(test_indices[i], "TT", TT, "num_nodes", data.num_nodes)

        '''防止忠诚度很小'''
        one_Fidelity = 0
        time_fidlity = 0
        select_max = -1
        select_max_coalition = []

        # 对节点的重要性排序，只取40%的节点作为第一个节点，最大不超过10
        graph_nodes = list(graph.nodes)
        score_dict = dict()
        for item in graph_nodes:

            if data.num_nodes - 1 > TT:
                score = score_func_my([item], data)
            else:
                score = score_func_l_shapley([item], data)

            score_dict[item] = score
        score_dict = dict(sorted(score_dict.items(), key=lambda x: x[1], reverse=True))
        score_dict_keys = list(score_dict.keys())

        if int(len(score_dict_keys) * 0.4 + 1) <= 4:
            score_dict_keys = score_dict_keys[:int(len(score_dict_keys) * 0.4 + 1)]
            score_dict_keys_num = len(score_dict_keys)
        else:
            score_dict_keys = score_dict_keys[:4]
            score_dict_keys_num = len(score_dict_keys)

        final_score = -1
        while one_Fidelity < 0.9:
            time_fidlity += 1

            # 得到第一个节点
            coalition = [score_dict_keys[time_fidlity % score_dict_keys_num]]
            if config.datasets.dataset_name in ['ba_2motifs']:
                if time_fidlity > score_dict_keys_num * 3:
                    break
                MIN_node = 4
                if time_fidlity >= score_dict_keys_num:
                    MIN_node = 5
                if time_fidlity >= score_dict_keys_num * 2 and one_Fidelity_final < 0.1:
                    MIN_node = int(data.num_nodes * 0.8)
            else:
                if time_fidlity > score_dict_keys_num * 4:
                    break
                MIN_node = 3
                if time_fidlity >= score_dict_keys_num:
                    MIN_node = 4
                if time_fidlity >= score_dict_keys_num * 2:
                    MIN_node = 5
                if time_fidlity >= score_dict_keys_num * 3 and one_Fidelity_final < 0.1:
                    MIN_node = int(data.num_nodes * 0.8)

            while (True):  # 直到满足条件则停止
                # 得到当前节点的邻居节点，去除重复节点和已经选定的节点，返回的是一维列表：adj_nodes
                adj_nodes = list()
                [adj_nodes.append(list(adj._atlas[i].keys())) for i in coalition]
                adj_nodes = list(set(_flatten(adj_nodes)))
                for node in coalition:
                    if node in adj_nodes:
                        adj_nodes.remove(node)

                # 如果coaltion没有邻居节点，则结束
                if len(adj_nodes) == 0:
                    one_Sparsity = len(coalition) / data.num_nodes
                    against_coalition = []
                    for node in graph.nodes:
                        if node not in coalition:
                            against_coalition.append(node)
                    against_coalition_probs = getACC(coalition=against_coalition, data=data, graph=graph, model=model)
                    one_Fidelity_inv = model_probs[label] - sub_probs[label]
                    one_Fidelity = model_probs[label] - against_coalition_probs[label]

                    if one_Fidelity > select_max:
                        select_max = one_Fidelity
                        one_Fidelity_final = one_Fidelity
                        one_Fidelity_inv_final = one_Fidelity_inv
                        one_Sparsity_final = one_Sparsity
                        select_max_coalition = coalition.copy()

                    print(coalition)
                    break

                maxScore = -1
                tmp = []
                for node in adj_nodes:
                    tmp.clear()
                    tempCoalition = coalition.copy()
                    tempCoalition.append(node)
                    # score = score_func(tempCoalition, data)

                    if data.num_nodes - len(tempCoalition) > TT:
                        score = score_func_my([item], data)
                    else:
                        score = score_func_l_shapley([item], data)

                    if score > maxScore:
                        maxScore = score
                        tmp = tempCoalition

                if len(tmp) == 0:
                    coalition.append(adj_nodes[0])
                else:
                    coalition = tmp

                sub_probs = getACC(coalition=coalition, data=data, graph=graph, model=model)
                # print(str(sub_probs[label]) + str(model_probs[label]))
                if model_probs[label] <= sub_probs[label] + 0.05 and len(coalition) >= MIN_node:
                    # if len(coalition) >= data.num_nodes * 0.5 - 1:
                    one_Sparsity = len(coalition) / data.num_nodes
                    against_coalition = []
                    for node in graph.nodes:
                        if node not in coalition:
                            against_coalition.append(node)
                    against_coalition_probs = getACC(coalition=against_coalition, data=data, graph=graph, model=model)
                    one_Fidelity = model_probs[label] - against_coalition_probs[label]
                    one_Fidelity_inv = model_probs[label] - sub_probs[label]

                    score = score_func_my(coalition, data)
                    if score > final_score:
                        one_Fidelity_final = one_Fidelity
                        one_Fidelity_inv_final = one_Fidelity_inv
                        one_Sparsity_final = one_Sparsity
                        select_max_coalition = coalition.copy()
                        final_score = score

                    # if one_Fidelity >= select_max or one_Fidelity - select_max < 0.01:
                    #     if time_fidlity >= 2 and one_Fidelity - one_Fidelity_final > 0.03:
                    #         select_max = one_Fidelity
                    #         one_Fidelity_final = one_Fidelity
                    #         one_Fidelity_inv_final = one_Fidelity_inv
                    #         one_Sparsity_final = one_Sparsity
                    #         select_max_coalition = coalition.copy()
                    #
                    #     if time_fidlity >= 2 and len(coalition) < len(select_max_coalition) and \
                    #             one_Fidelity_final - one_Fidelity < 0.0:
                    #         select_max = one_Fidelity
                    #         one_Fidelity_final = one_Fidelity
                    #         one_Fidelity_inv_final = one_Fidelity_inv
                    #         one_Sparsity_final = one_Sparsity
                    #         select_max_coalition = coalition.copy()
                    #
                    #     if time_fidlity == 1:
                    #         select_max = one_Fidelity
                    #         one_Fidelity_final = one_Fidelity
                    #         one_Fidelity_inv_final = one_Fidelity_inv
                    #         one_Sparsity_final = one_Sparsity
                    #         select_max_coalition = coalition.copy()

                    print('one_Fidelity:', round(one_Fidelity.item(), 4), ",score:", round(score, 4), coalition)
                    break

        # 画图
        print("one_Fidelity_final:", round(one_Fidelity_final.item(), 4),
              ",final_score:", round(final_score, 4),
              select_max_coalition)
        Fidelity += one_Fidelity_final
        Fidelity_inv += one_Fidelity_inv_final
        Sparsity += one_Sparsity_final
        coalition = select_max_coalition.copy()

        title_sentence = f'fide: {one_Fidelity_final:.3f}, ' \
                         f'fide_inv: {one_Fidelity_inv_final:.3f}, ' \
                         f'spar: {1 - one_Sparsity_final:.3f}'
        title_sentence = ""

        if config.datasets.dataset_name in ['twitter', 'graph_sst2', 'graph_sst5']:
            words = dataset.supplement.get('sentence_tokens').get(str(test_indices[i]))
        else:
            words = None

        predict_true = 'True' if prediction == data.y.item() else "False"

        one_Sparsity_final = format(one_Sparsity_final, '.4f')
        one_Fidelity_final = format(one_Fidelity_final, '.4f')
        one_Fidelity_inv_final = format(one_Fidelity_inv_final, '.4f')
        path = os.path.join(explanation_saving_dir, f'example_{test_indices[i]}_'
                                                    f'prediction_{prediction}_'
                                                    f'label_{data.y.item()}_'
                                                    f'pred_{predict_true}'
                                                    f'sparsity_{one_Sparsity_final}_'
                                                    f'Fidelity_{one_Fidelity_final}_'
                                                    f'Fidelity+_{one_Fidelity_inv_final}.png'
                            )

        plot_graph(dataname=config.datasets.dataset_name,
                   plot_utils=plot_utils,
                   graph=graph,
                   coalition=coalition,
                   x=data.x,
                   title_sentence=title_sentence,
                   figname=path,
                   words=words)

        '''对找出的节点进行重要性排序'''
        coalition_nums = len(coalition)
        res_coalition = coalition.copy()
        # print(res_coalition)
        dict_coalition = dict()
        for node in res_coalition:
            dict_coalition[node] = 0

        coalition.clear()
        times = 0  # 加入噪声的次数
        while times < 20:
            copy_data = data.clone()
            times += 1
            # 找出随机的2个节点，将特征向量设置为0，加入噪声
            random_coaltion = list()
            while len(random_coaltion) != 2:
                tmp = random.randint(0, copy_data.num_nodes - 1)
                if random_coaltion.__contains__(tmp):
                    continue
                random_coaltion.append(tmp)
            # print("random_coaltion:", random_coaltion)
            copy_data.x[random_coaltion, :] = 0

            maxScore = -1
            coalition = []
            if IS_DELETE_MAX_DEGREE:
                node_degree_list = sorted(graph.degree, key=lambda x: x[1], reverse=True)
                graph_nodes = list(graph.nodes)

                if len(graph_nodes) > 3:  # 删除度最大的k个节点
                    for k in range(3):
                        graph_nodes.remove(node_degree_list[k][0])
                tempCoalition = []

                for item in graph_nodes:
                    tempCoalition.clear()  # 选择第一个节点
                    tempCoalition.append(item)
                    # score = score_func(tempCoalition, data)
                    if data.num_nodes - len(tempCoalition) > TT:
                        score = score_func_my([item], data)
                    else:
                        score = score_func_l_shapley([item], data)

                    if score > maxScore:
                        maxScore = score
                        coalition.clear()
                        coalition = tempCoalition.copy()
            else:
                for item in range(data.num_nodes):
                    tempCoalition = []
                    tempCoalition.append(item)
                    # score = score_func(tempCoalition, data)  # score_func计算shapley值得分
                    if data.num_nodes - len(tempCoalition) > TT:
                        score = score_func_my([item], data)
                    else:
                        score = score_func_l_shapley([item], data)

                    if score > maxScore:
                        maxScore = score
                        coalition = tempCoalition  # coalition存储贡献最大的节点

            while (True):  # 直到满足条件则停止
                # 得到当前节点的邻居节点，去除重复节点和已经选定的节点，返回的是一维列表：adj_nodes
                adj_nodes = list()
                [adj_nodes.append(list(adj._atlas[i].keys())) for i in coalition]
                adj_nodes = list(set(_flatten(adj_nodes)))
                for node in coalition:
                    if node in adj_nodes:
                        adj_nodes.remove(node)

                # 如果coaltion没有邻居节点，则结束
                if len(adj_nodes) == 0:
                    for node in coalition:
                        if dict_coalition.__contains__(node):
                            dict_coalition[node] = dict_coalition.get(node) + 1
                    break

                maxScore = -1
                tmp = []
                for node in adj_nodes:
                    tmp.clear()
                    tempCoalition = coalition.copy()
                    tempCoalition.append(node)
                    # score = score_func(tempCoalition, copy_data)
                    if data.num_nodes - len(tempCoalition) > TT:
                        score = score_func_my([item], data)
                    else:
                        score = score_func_l_shapley([item], data)

                    if score > maxScore:
                        maxScore = score
                        tmp = tempCoalition

                if len(tmp) == 0:
                    coalition.append(adj_nodes[0])
                else:
                    coalition = tmp

                sub_probs = getACC(coalition=coalition, data=copy_data, graph=graph, model=model)
                # if model_probs[label] <= sub_probs[label] + 0.05 and len(coalition) >= 5:
                # if len(coalition) >= coalition_nums * 0.4 and len(coalition) >= 2 or len(coalition) >= 6:
                if len(coalition) >= coalition_nums * 0.2 and len(coalition) >= 2:
                    for node in coalition:
                        if dict_coalition.__contains__(node):
                            dict_coalition[node] = dict_coalition.get(node) + 1
                    break

        path = os.path.join(explanation_saving_dir, f'example_{test_indices[i]}_'
                                                    f'prediction_{prediction}_'
                                                    f'label_{data.y.item()}_'
                                                    f'pred_{predict_true}'
                                                    f'sparsity_{one_Sparsity_final}_'
                                                    f'Fidelity_{one_Fidelity_final}_'
                                                    f'Fidelity+_{one_Fidelity_inv_final}_important.png'
                            )

        # 按重要性进行排序后的节点进行画图
        print(dict_coalition)
        plot_important_node(dataname=config.datasets.dataset_name,
                            dict_coalition=dict_coalition,
                            path=path,
                            data=data,
                            graph=graph)

        K = 1
        delete_important_nodes_prop, delete_unimportant_nodes_prop = \
            delete_node_prop(dict_coalition=dict_coalition, K=K, data=data, graph=graph, model=model)

        delete_important_node_1 += model_probs[label] - delete_important_nodes_prop[label]
        delete_unimportant_node_1 += model_probs[label] - delete_unimportant_nodes_prop[label]

        K = 2
        delete_important_nodes_prop, delete_unimportant_nodes_prop = \
            delete_node_prop(dict_coalition=dict_coalition, K=K, data=data, graph=graph, model=model)

        delete_important_node_2 += model_probs[label] - delete_important_nodes_prop[label]
        delete_unimportant_node_2 += model_probs[label] - delete_unimportant_nodes_prop[label]

        K = 3
        delete_important_nodes_prop, delete_unimportant_nodes_prop = \
            delete_node_prop(dict_coalition=dict_coalition, K=K, data=data, graph=graph, model=model)

        delete_important_node_3 += model_probs[label] - delete_important_nodes_prop[label]
        delete_unimportant_node_3 += model_probs[label] - delete_unimportant_nodes_prop[label]

    print("Sparsity = %.2f" % (1 - Sparsity / len(test_indices)),
          "Fidelity_inv = %.4f" % (Fidelity_inv / len(test_indices)),
          "Fidelity = %.4f" % (Fidelity / len(test_indices)))

    print("delete ", 1, "nodes", "important:", delete_important_node_1 / len(test_indices),
          " unimportant:", delete_unimportant_node_1 / len(test_indices))
    print("delete ", 2, "nodes", "important:", delete_important_node_2 / len(test_indices),
          " unimportant:", delete_unimportant_node_2 / len(test_indices))
    print("delete ", 3, "nodes", "important:", delete_important_node_3 / len(test_indices),
          " unimportant:", delete_unimportant_node_3 / len(test_indices))

    print(config.datasets.dataset_name, config.explainers.param.get('reward_method'))
    print('Acc:', True_num / len(test_indices))


def getACC(coalition, data, graph, model):
    clone_data = data.x.clone()
    nodes = list(graph.nodes)
    [nodes.remove(i) for i in coalition]
    clone_data[nodes, :] = 0  # 将不重要的节点特征设置为0
    probs = model(clone_data, data.edge_index).squeeze().softmax(dim=-1)
    return probs


def plot_graph(dataname, plot_utils, graph, coalition, x, title_sentence, figname, words=None):
    plot_utils.plot(graph,
                    coalition,
                    words=words,
                    x=x,
                    title_sentence=title_sentence,
                    figname=figname)


def plot_important_node(dataname, dict_coalition, path, data, graph):
    # 对原图的子图中的节点进行重要行排序，按值降序排序
    dict_coalition = dict(sorted(dict_coalition.items(), key=lambda x: x[1], reverse=True))
    subgrap_coalition = list(dict_coalition.keys())
    # print(subgrap_coalition)
    pos = nx.kamada_kawai_layout(graph)
    pos_nodelist = {k: v for k, v in pos.items() if k in subgrap_coalition}

    alpha = dict()  # 设置透明度
    for i in graph.nodes:
        alpha[i] = 0

    if dict_coalition.get(subgrap_coalition[0]) != 0:
        for i in subgrap_coalition:
            if dict_coalition.get(subgrap_coalition[0]) == 0:
                alpha[i] = 0.1
            else:
                alpha[i] = dict_coalition.get(i) / dict_coalition.get(subgrap_coalition[0])
            if alpha[i] < 0.1:
                alpha[i] = 0.1  # 透明度最小为0.1
    else:
        for i in range(len(alpha)):
            alpha[i] = 0.1
    alpha_items = list(alpha.values())
    nx.draw_networkx_nodes(graph, pos,  # 先画一圈黑色
                           nodelist=list(graph.nodes()),
                           node_color='#000000',
                           node_size=400)

    nx.draw_networkx_nodes(graph, pos,  # 在画一圈白色
                           nodelist=list(graph.nodes()),
                           node_color='#ffffff',
                           node_size=300)

    nx.draw_networkx_nodes(graph, pos,  # 根据重要性程度排序，叠加掩盖
                           nodelist=list(graph.nodes()),
                           node_color='#ed6618',
                           alpha=alpha_items,
                           node_size=300)

    nx.draw_networkx_edges(graph, pos, width=3, edge_color='gray', arrows=False)  # 先画所有边，gray
    edgelist = [(n_frm, n_to) for (n_frm, n_to) in graph.edges()
                if n_frm in subgrap_coalition and n_to in subgrap_coalition]

    nx.draw_networkx_edges(graph, pos=pos_nodelist,  # 把子图节点用另外一种边连接起来
                           edgelist=edgelist, width=4,
                           edge_color='#ed6618',
                           alpha=0.5,
                           arrows=False)
    plt.axis('off')
    # plt.show()
    plt.savefig(path)
    plt.close()


def delete_node_prop(dict_coalition, K, data, graph, model):
    # 对原图的子图中的节点进行重要行排序，按值降序排序
    dict_coalition = dict(sorted(dict_coalition.items(), key=lambda x: x[1], reverse=True))
    subgrap_coalition = list(dict_coalition.keys())
    delete_important_nodes = subgrap_coalition[K:]
    delete_important_nodes_prop = getACC(coalition=delete_important_nodes,
                                         data=data,
                                         graph=graph,
                                         model=model)
    delete_unimportant_nodes = subgrap_coalition[:len(subgrap_coalition) - K]
    delete_unimportant_nodes_prop = getACC(coalition=delete_unimportant_nodes,
                                           data=data,
                                           graph=graph,
                                           model=model)
    return delete_important_nodes_prop, delete_unimportant_nodes_prop


if __name__ == '__main__':
    import sys
    import datetime

    start = datetime.datetime.now()
    # 中间写上代码块
    sys.argv.append('explainers=mycode')
    pipeline()
    end = datetime.datetime.now()
    print('Running time: %s Seconds' % (end - start))
