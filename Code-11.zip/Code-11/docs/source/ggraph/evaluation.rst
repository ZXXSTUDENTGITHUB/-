dig.ggraph.evaluation
============
Evaluation interfaces under :obj:`dig.ggraph.evaluation`.

.. automodule:: dig.ggraph.evaluation
    :members:
    :special-members:
    :autosummary:
    :autosummary-no-nesting: