dig.xgraph.dataset
=========
Dataset interfaces under :obj:`dig.xgraph.dataset`.

.. automodule:: dig.xgraph.dataset
    :members: MoleculeDataset, SentiGraphDataset, BA_LRP, SynGraphDataset
    :special-members:
    :autosummary:
    :autosummary-no-nesting:
