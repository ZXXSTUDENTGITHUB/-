dig.xgraph.evaluation
======
Evaluation interfaces under :obj:`dig.xgraph.evaluation`.

.. automodule:: dig.xgraph.evaluation
    :members:
    :special-members:
    :autosummary:
    :autosummary-no-nesting:
