dig.xgraph.method
========
Methods interfaces under :obj:`dig.xgraph.method`.

.. automodule:: dig.xgraph.method
    :members:
    :special-members:
    :autosummary:
    :autosummary-no-nesting:
    :exclude-members: MCTS
