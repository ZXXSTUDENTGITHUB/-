dig.threedgraph.evaluation
======
Evaluation interfaces under :obj:`dig.threedgraph.evaluation`.

.. automodule:: dig.threedgraph.evaluation
    :members:
    :special-members: