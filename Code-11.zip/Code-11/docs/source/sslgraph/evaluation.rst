dig.sslgraph.evaluation
============
Evaluation interfaces under :obj:`dig.sslgraph.evaluation`.

.. automodule:: dig.sslgraph.evaluation
    :members:
    :special-members:
    :autosummary:
    :autosummary-no-nesting: