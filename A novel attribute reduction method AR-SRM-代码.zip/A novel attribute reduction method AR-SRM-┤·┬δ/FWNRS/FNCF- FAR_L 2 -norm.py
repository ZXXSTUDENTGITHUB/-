import time
import copy
import pandas as pd
import numpy as np
import csv
from sklearn.preprocessing import MinMaxScaler


def FARNeMF():  # Fast forward attribute reduction algorithm based on classical rough set
    # Step 1:  
    # start1=time.process_time()
    red = [-1, -2]  
    smp_chk = U1  
    C_red = list(C)  
    F_pos = 0
    # Step 2:
    while smp_chk.shape[0]: 
        temp_POS = []  
        temp_ROW = []
        temp_k = 0  
        for k in C_red:
            attribute = list(red)
            attribute.append(k)
            DT = U1[:, attribute]
            POS = []  
            ROW = []  
            for x in smp_chk[:, -1]:
                if get_neighborhood(int(x), DT):
                    POS.append(int(x))
                    ROW.append(np.where(smp_chk[:, -1] == x)[0])

            if len(temp_POS) < len(POS):
                
                temp_POS = list(POS)
                temp_ROW = list(ROW)
                temp_k = k
        if temp_POS:  
            F_pos += len(temp_ROW)
            red.append(temp_k)
            C_red.remove(temp_k)
            smp_chk = np.delete(smp_chk, temp_ROW, axis=0)

        else:  
            del red[0]
            del red[0]
            return red, F_pos
    del red[0]
    del red[0]
    # print("dgdgdg", smp_chk)
    return red, F_pos


def RS_Fast():
    """
    :return:
    """
    # step1、Using the sorted matrix, quickly find the first attribute to be added, and save the remaining sample points, their neighborhoods and distances
    label = U[:, -1]  # label
    pos = []  
    T_len = 0
    R_Dic = []  # Save neighborhood matrix
    R_pos = []  #
    R_Dis=[]#save distance
    arr = [i for i in range(0, numberAttribute - 1)]
    Row = []
    re_arr = 0
    pos_num = 0
    sigema_Sq=np.square(sigema)

    for i in range(0, numberAttribute - 1):
        cmk_chk = U[:, i]  
        chk_Sort = sort_U[:, i]  # sort
        l = r = 0  # left and right
        rest = []
        temp_len = 0
        temp_pos = []
        for xj in chk_Sort:
            loaXj = cmk_chk[xj] 
            while l < r and cmk_chk[chk_Sort[l]] - loaXj < -sigema:
                l += 1
                rest.pop(0)
            while r < numberSample and cmk_chk[chk_Sort[r]] - loaXj <= sigema:
                rest.append(chk_Sort[r])
                r += 1
            tag1 = label[xj]
            tag2 = True
            for j in range(r - l):
                if label[rest[j]] != tag1:
                    tag2 = False
                    break
            if tag2:
                temp_pos.append(xj)  
                temp_len += 1

        if temp_len > T_len:
            re_arr = i
            T_len = temp_len
            pos = temp_pos  # 

    R_pos = list(sort_U[:, re_arr])
    if T_len:
        arr.remove(re_arr)  
        Row.append(re_arr)  
        chk_Sort2 = R_pos.copy()
        cl = 0
        pos_num += len(pos)
        for t in range(numberSample):
            if chk_Sort2[t] in pos:
                pos.remove(R_pos[t - cl])
                R_pos.pop(t - cl)
                cl += 1
        l = r = 0
        cmk_chk = U[:, re_arr]
        rest = []
        dist=[]
        re_len = len(R_pos)
        for xj in R_pos:
            loaXj = cmk_chk[xj]  
            while l < r and cmk_chk[R_pos[l]] - loaXj < -sigema:
                l += 1
                rest.pop(0)
            for w in range(r, re_len):
                d = cmk_chk[R_pos[r]] - loaXj
                if d <= sigema:
                    r += 1
                    rest.append(R_pos[w])
                else:
                    break

            rest1 = copy.deepcopy(rest)
            R_Dic.append(rest1)
            dist=list(np.square(np.array(cmk_chk[rest1])-loaXj))
            R_Dis.append(dist)
    else:
        return Row, pos_num

    while len(R_Dic) > 0:
        pos = []
        Tr_len = 0
        re_arr = -1
        for i in arr:
            T_len = 0
            T_pos = []
            new_arr = U[:, [i, -1]]
            for j in range(len(R_pos)):
                loaXj = new_arr[R_pos[j], 0]
                lolab = label[R_pos[j]]
                flag = True
                for ki,k in enumerate(R_Dic[j]):
                    if new_arr[k][1] != lolab and  (np.square(new_arr[k][0] - loaXj)+R_Dis[j][ki])<sigema_Sq:
                        flag = False
                        break
                if flag:
                    T_pos.append(R_pos[j])
                    T_len += 1
            if T_len > Tr_len:
                Tr_len = T_len
                pos = copy.deepcopy(T_pos)
                re_arr = i
        
        if Tr_len > 0:
            li = 0
            pos_num += len(pos)
            arr.remove(re_arr)
            Row.append(re_arr)
            for i in range(len(R_pos)):
                if R_pos[i - li] in pos:
                    R_Dic.pop(i - li)
                    R_pos.pop(i - li)
                    R_Dis.pop(i - li)
                    li += 1
            UDate = U[:, re_arr]
            tr = 0
            for r in R_Dic:
                lr = 0
                lo = UDate[R_pos[tr]]
                T_Rs=R_Dis[tr]
                tr += 1
                
                for j in range(len(r)):
                    # print("lenpos",len(pos))
                    T_d=T_Rs[j-lr]+np.square(UDate[r[j - lr]] - lo)
                    if r[j - lr] in pos or  T_d> sigema_Sq:
                        r.pop(j - lr)
                        T_Rs.pop(j-lr)
                        lr += 1
                    else:
                        T_Rs[j-lr]=T_d
        else:
            return Row, pos_num
    return Row, pos_num


def get_neighborhood(x, DT):  # If the calculation field is a positive field, return true, otherwise return false, and the judgment of the positive field is different

    Mul_Array = DT[list(np.where(DT[:, 1] != DT[x, 1])[0]), :]
    rlen = len(DT[0])
    loxj = DT[x][2:rlen]
    min1 = np.sqrt(np.sum(np.square(Mul_Array[0][2:rlen] - loxj)))
    for k in range(1, len(Mul_Array)):
        tlen = np.sqrt(np.sum(np.square(Mul_Array[k][2:rlen] - loxj)))
        if tlen < min1:
            min1 = tlen
    if min1 < sigema:
        return False
    else:
        return True
def mean_std(a):
    # Calculate the mean and standard deviation of one-dimensional array
    a = np.array(a)
    std = np.sqrt(((a - np.mean(a)) ** 2).sum() / (a.size - 1))
    return a.mean(), std

if __name__ == '__main__':
    # dataa = [, "german",
    dataa=[ 'htru2']#,
             # , '' \
        #, '', , 'mushroom1', ]  # 'sonar', 'wdbc' 'LEUKEMIA','iono','iris',"hepatitis","hepatitis","horse","horse", "lymphography"
    with open("F:\py\save.csv", "a", newline='', encoding="utf-8") as jg:
        writ = csv.writer(jg)
        for k in range(len(dataa)):
            # start = time.process_time()
            df = pd.read_csv("F:\\py\\UCI\\" + dataa[k] + ".csv", header=None)
            data = df.values
            data = data[:10000, :]
            writ.writerow([dataa[k], str(data.shape)])
            numberSample, numberAttribute = data.shape
            writ.writerow(["δ", "S_Reduct", "F_Reduct", "SFARNEMF", "FARNEMF", "SFARNEMF", "FARNEMF"])
            minMax = MinMaxScaler()  # Normalize the data
            U = np.hstack((minMax.fit_transform(data[:, 1:]), data[:, 0].reshape(numberSample, 1)))  
            C = list(np.arange(0, numberAttribute - 1))  # condition attribute
            D = list(set(U[:, -1]))  # decision attribute
            index = np.array(range(0, numberSample)).reshape(numberSample, 1)  
            sort_U = np.argsort(U[:, 0:-1], axis=0)
            U1 = np.hstack((U, index))  
            time1 = time2 = 0
            sigema = 0.05
            # for i in range(1, 2):
            print("sigima", sigema)
            F_posnum = R_posnum = 0
            start1 = time.process_time()
            red1, F_posnum = FARNeMF()
            end1 = time.process_time()
            print("red", red1," time：",end1-start1)
            F_time = end1 - start1
            start2 = time.process_time()
            Row, R_posnum = RS_Fast()
            end2 = time.process_time()
            R_time = end2 - start2
            print("ROW", Row,"  time：",R_time)
            writ.writerow([sigema, Row, red1, R_time, F_time, R_posnum, F_posnum])
            # sigema=0.1*i
            writ.writerow([" "])


