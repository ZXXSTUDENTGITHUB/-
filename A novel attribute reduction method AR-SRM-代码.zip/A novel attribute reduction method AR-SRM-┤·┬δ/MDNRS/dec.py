import numpy as np

def dec(decision,olen):
	labels = np.unique(decision)
	dnum = len(labels)
	DR = np.zeros((olen, dnum))
	for d in range(dnum):
		print(labels[d])
		DR[:, d] = decision == labels[d]
	return dnum, DR
