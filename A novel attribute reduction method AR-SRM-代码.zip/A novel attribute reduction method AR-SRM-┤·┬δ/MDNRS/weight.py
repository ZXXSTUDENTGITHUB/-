import numpy as np


def Weight(condition, decision, flag):

    if flag==0:
        W=np.linalg.solve(np.matmul(np.transpose(condition),condition),np.matmul(np.transpose(condition),decision))
    else:
        W=np.linalg.solve(np.matmul(np.transpose(condition),condition)+np.eye(condition[0].__len__(),\
                                    condition[0].__len__()),np.matmul(np.transpose(condition),decision))
    sum_v = 0
    len = 0
    for v in W:
        sum_v += np.abs(v)
        len += 1
    WW = []
    for v in W:
        WW.append(np.abs(v)*len/(sum_v))

    return WW

