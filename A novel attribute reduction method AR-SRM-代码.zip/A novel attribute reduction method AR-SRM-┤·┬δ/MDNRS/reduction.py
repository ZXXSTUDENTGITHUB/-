import numpy as np
from dec import dec
from distance import distance
import copy
def reduction(condition,decision,delta,olen,wlen):
	diss=distance(condition,olen,wlen)
	diss=np.array(diss)
	dnum,DR=dec(decision,olen)
	red=[]
	gamma_old=-float('inf')
	delta2=np.square(delta)
	C=[i for i in range(wlen)]#
	while C:
		opt_gamma=-1
		ak=0
		for a in C:
			pos=np.zeros((olen,1))
			redd=copy.deepcopy(red)
			redd.append(a)
			WN=sum(diss[redd,:,:])<=delta2
			clen=sum(WN)
			for d in range(dnum):
				WN=np.array(WN)
				WT=np.tile(DR[:,d],(olen,1)).transpose()
				c=sum(np.where(np.logical_and(WN>0,WT>0),1,0))==clen
				pos[c]=1
				pos.tolist()
			gamma=sum(pos)/olen
			if gamma>opt_gamma:
				opt_gamma=gamma
				ak=a
		sig=opt_gamma-gamma_old
		if sig>0:
			gamma_old=opt_gamma
			red.append(ak)
			C.remove(ak)
		else:
			break
	return red


