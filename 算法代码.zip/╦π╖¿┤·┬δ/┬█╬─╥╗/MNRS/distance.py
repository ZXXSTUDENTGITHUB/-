import numpy as np

def distance(condition,olen,wlen):
	diss = np.zeros((wlen, olen, olen))
	condition = np.array(condition)
	for a in range(0, wlen):
		objs = condition[:, a]
		diss[a, :, :] = np.square(np.tile(objs.T, (olen, 1)).T - np.tile(objs.T, (olen, 1)))
	return diss
