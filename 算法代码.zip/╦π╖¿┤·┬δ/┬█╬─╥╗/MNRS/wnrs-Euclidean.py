import copy
import time
from sklearn.neighbors import KNeighborsClassifier
import numpy as np
import warnings
from reduction import reduction
from weight import Weight
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import cross_val_score
import pandas as pd
import os
import csv


def wnrsreduction(data, delta, flag):
    warnings.filterwarnings('ignore')
    condition = data[:, 1:]
    decision = data[:, 0]
    olen, wlen = condition.shape
    w = Weight(condition, decision, flag)
    condition = condition * np.tile(w, (olen, 1))
    red = reduction(condition, decision, delta, olen, wlen)
    return red

def RS_Fast():

    label = U[:, -1]
    pos = []
    T_len = 0
    R_Dic = []

    R_Dis=[]
    arr = [i for i in range(0, numberAttribute - 1)]
    Row = []
    re_arr = 0
    pos_num = 0
    sigema_Sq=np.square(sigema)

    for i in range(0, numberAttribute - 1):
        cmk_chk = U[:, i]
        chk_Sort = sort_U[:, i]
        l = r = 0
        rest = []#Temporarily save the samples in the neighborhood of each sample point
        temp_len = 0
        temp_pos = []
        for xj in chk_Sort:
            loaXj = cmk_chk[xj]
            while l < r and cmk_chk[chk_Sort[l]] - loaXj < -sigema:
                l += 1
                rest.pop(0)
            while r < numberSample and cmk_chk[chk_Sort[r]] - loaXj <= sigema:
                rest.append(chk_Sort[r])
                r += 1
            tag1 = label[xj]
            tag2 = True
            for j in range(r - l):
                if label[rest[j]] != tag1:
                    tag2 = False
                    break
            if tag2:
                temp_pos.append(xj)
                temp_len += 1

        if temp_len > T_len:
            re_arr = i
            T_len = temp_len
            pos = temp_pos

    R_pos = list(sort_U[:, re_arr])
    if T_len:
        arr.remove(re_arr)
        Row.append(re_arr)
        chk_Sort2 = R_pos.copy()
        cl = 0
        pos_num += len(pos)
        for t in range(numberSample):
            if chk_Sort2[t] in pos:
                pos.remove(R_pos[t - cl])
                R_pos.pop(t - cl)
                cl += 1
        l = r = 0
        cmk_chk = U[:, re_arr]
        rest = []

        re_len = len(R_pos)
        for xj in R_pos:
            loaXj = cmk_chk[xj]
            while l < r and cmk_chk[R_pos[l]] - loaXj < -sigema:
                l += 1
                rest.pop(0)
            for w in range(r, re_len):
                d = cmk_chk[R_pos[r]] - loaXj
                if d <= sigema:
                    r += 1
                    rest.append(R_pos[w])
                else:
                    break

            rest1 = copy.deepcopy(rest)
            R_Dic.append(rest1)
            dist=list(np.square(np.array(cmk_chk[rest1])-loaXj))
            R_Dis.append(dist)
    else:
        return Row, pos_num

    while len(R_Dic) > 0:
        pos = []
        Tr_len = 0
        re_arr = -1
        for i in arr:
            T_len = 0
            T_pos = []
            new_arr = U[:, [i, -1]]
            for j in range(len(R_pos)):
                loaXj = new_arr[R_pos[j], 0]
                lolab = label[R_pos[j]]
                flag = True
                for ki,k in enumerate(R_Dic[j]):
                    if new_arr[k][1] != lolab and  (np.square(new_arr[k][0] - loaXj)+R_Dis[j][ki])<sigema_Sq:
                        flag = False
                        break
                if flag:
                    T_pos.append(R_pos[j])
                    T_len += 1
            if T_len > Tr_len:
                Tr_len = T_len
                pos = copy.deepcopy(T_pos)
                re_arr = i

        if Tr_len > 0:
            li = 0
            pos_num += len(pos)
            arr.remove(re_arr)
            Row.append(re_arr)
            for i in range(len(R_pos)):
                if R_pos[i - li] in pos:
                    R_Dic.pop(i - li)
                    R_pos.pop(i - li)
                    R_Dis.pop(i - li)
                    li += 1
            UDate = U[:, re_arr]
            tr = 0
            for r in R_Dic:
                lr = 0
                lo = UDate[R_pos[tr]]
                T_Rs=R_Dis[tr]
                tr += 1

                for j in range(len(r)):

                    T_d=T_Rs[j-lr]+np.square(UDate[r[j - lr]] - lo)
                    if r[j - lr] in pos or  T_d> sigema_Sq:
                        r.pop(j - lr)
                        T_Rs.pop(j-lr)
                        lr += 1
                    else:
                        T_Rs[j-lr]=T_d
        else:
            return Row, pos_num
    return Row, pos_num


def get_neighborhood(x, DT):  # Calculate the neighborhood

    Mul_Array = DT[list(np.where(DT[:, 1] != DT[x, 1])[0]), :]
    rlen = len(DT[0])
    loxj = DT[x][2:rlen]
    min1 = np.sqrt(np.sum(np.square(Mul_Array[0][2:rlen] - loxj)))
    for k in range(1, len(Mul_Array)):
        tlen = np.sqrt(np.sum(np.square(Mul_Array[k][2:rlen] - loxj)))
        if tlen < min1:
            min1 = tlen
    if min1 < sigema:
        return False
    else:
        return True
def mean_std(a):

    a = np.array(a)
    std = np.sqrt(((a - np.mean(a)) ** 2).sum() / (a.size - 1))
    return a.mean(), std

if __name__ == '__main__':
    flist = os.listdir("../DataSet")
    # clf = KNeighborsClassifier()
    url1 = "../DataSet/zoo.csv"
    with open(url1, 'a+', encoding='utf-8-sig', newline='') as jg:
        writ = csv.writer(jg)
        for file in flist:
            print("name:",file)
            url = "../DataSet/" + file
            df = pd.read_csv(url, header=None)
            data = df.values
            numberSample, numberAttribute = data.shape
            minMax = MinMaxScaler()
            data = np.hstack((data[:, 0].reshape(numberSample, 1), minMax.fit_transform(data[:, 1:])))
            U = np.hstack((minMax.fit_transform(data[:, 1:]), data[:, 0].reshape(numberSample, 1)))
            C = list(np.arange(0, numberAttribute - 1))  # Condition attribute
            D = list(set(U[:, -1]))  # decision attribute
            writ.writerow([file,data.shape])
            writ.writerow(['sigema', 'red', 'Row', 'R_time', 'F_time', 'R_posnum'])
            # calculate weights
            condition = U[:, :-1]
            decision = U[:, -1]
            weight = Weight(condition, decision, 1)
            print("weight:", weight)
            weight.append(1)
            U = U * weight
            index = np.array(range(0, numberSample)).reshape(numberSample, 1)
            sort_U = np.argsort(U[:, 0:-1], axis=0)
            U1 = np.hstack((U, index))  # plus the index list

            for i in range(1, 51):
                deerta = i * 0.01
                sigema = deerta
                s1 = time.process_time()
                red = wnrsreduction(data, deerta, 1)
                red=[1]
                # red = np.array(red)
                e1 = time.process_time()
                # writ.writerow()
                F_posnum = R_posnum = 0
                start1 = time.process_time()
                # red1, F_posnum = FARNeMF()
                red1 = [1]
                F_posnum = 1
                end1 = time.process_time()
                print("red", red1, " 时间：", end1 - start1)
                F_time = e1 - s1
                start2 = time.process_time()
                Row, R_posnum = RS_Fast()
                print("posnum:",R_posnum)
                end2 = time.process_time()
                R_time = end2 - start2
                print("ROW", Row, "  时间：", R_time)
                print(sigema, red, Row, R_time, F_time, R_posnum)
                writ.writerow([sigema, red, Row, R_time, F_time, R_posnum])
            writ.writerow([" "])

