num_clusters = 10
# cluster_labels_cifar10_
# cluster_se_labels_cifar10_
path_file = 'cluster_labels_fashion_'