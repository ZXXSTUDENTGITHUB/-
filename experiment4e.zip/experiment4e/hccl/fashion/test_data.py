import torch
import torchvision
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
import time
import sys


minist_train = torchvision.datasets.FashionMNIST(root='../data/FashionMNIST/',train=True,download=True,transform=transforms.ToTensor())
minist_test = torchvision.datasets.FashionMNIST(root='../data/FashionMNIST/',train=True,download=True,transform=transforms.ToTensor())

print(type(minist_train))
print(len(minist_train),len(minist_test))
