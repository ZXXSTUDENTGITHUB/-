# loaddataset.py
from torchvision.datasets import FashionMNIST
from PIL import Image


class PreDataset(FashionMNIST):
    def __getitem__(self, item):
        img,target=self.data[item],self.targets[item]
        img = Image.fromarray(img.numpy())

        if self.transform is not None:
            imgL = self.transform(img)
            imgR = self.transform(img)

        if self.target_transform is not None:
            target = self.target_transform(target)

        return imgL, imgR, target


if __name__=="__main__":

    import hccl.fashion.a_train_fashion_config
    train_data = PreDataset(root='../data/FashionMNIST', train=True, transform=hccl.fashion.a_train_fashion_config.train_transform, download=True)
    print(111)
    print(train_data[0])
