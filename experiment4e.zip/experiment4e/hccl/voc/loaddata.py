# loaddataset.py
from torchvision.datasets import FashionMNIST
from torchvision.transforms import ToTensor, Grayscale
from torchvision import  transforms
from PIL import Image


class PreDataset(FashionMNIST):
    def __getitem__(self, item):
        img, target = super().__getitem__(item)
        # 将灰度图像转换为 RGB 形式
        img = Grayscale(num_output_channels=3)(img)
        img = ToTensor()(img)  # 将图像转换为 PyTorch Tensor

        if self.transform is not None:
            imgL = self.transform(img)
            imgR = self.transform(img)

        if self.target_transform is not None:
            target = self.target_transform(target)

        return imgL, imgR, target


if __name__=="__main__":


    import hccl.voc.config

    train_data = PreDataset(root='../data', train=True, download=True, transform=hccl.voc.config.train_transform)

    print(train_data[0])
