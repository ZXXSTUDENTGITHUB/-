import os
import matplotlib
from sklearn.cluster import KMeans
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset, Subset
import torchvision
import torchvision.datasets as datasets
from torchvision import transforms
import torch.multiprocessing
import logging
from cluster.ImageEmb import ImageEmbedding
import datetime
from torch.optim import RMSprop
import torch.optim as optim
import numpy as np
from hccl.model.se_resnet import se_resnet20

torch.multiprocessing.set_sharing_strategy('file_system')
matplotlib.use('Agg')
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')


def data_augmentation(image_size):
    return transforms.Compose([
        transforms.Resize(size=(256, 256)),
        transforms.RandomResizedCrop(size=image_size, scale=(0.8, 1.0)),
        # transforms.RandomCrop(size=image_size, padding=int(image_size / 8)),
        transforms.RandomGrayscale(p=0.2),
        transforms.RandomRotation(degrees=15),
        transforms.ColorJitter(brightness=0.1, contrast=0.1, saturation=0.1, hue=0.1),
        transforms.Resize(image_size),
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    ])


def get_data_loaders(target_size=96):  # target_size=(96, 96)
    # set log level as WARNING
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    data_dir = './data'
    download = False

    if not os.path.exists(data_dir):
        download = True

    seed = 2245
    # CIFAR-100 dataset
    train_dataset = datasets.CIFAR10(root=data_dir, train=True, download=True, transform=transforms.ToTensor())
    test_dataset = datasets.CIFAR10(root=data_dir, train=False, download=True, transform=transforms.ToTensor())

    batch_size = 128

    # DataLoader
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)


    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=False, num_workers=0, drop_last=True)

    print("File ready")

    return train_loader, test_loader


# get features
def extract_features(loader, model):
    features = []
    labels = []
    # model.eval()
    with torch.no_grad():
        for images, targets in loader:
            features.append(model(images).detach())
            labels.append(targets)
    print('extract_features done')
    return torch.cat(features), torch.cat(labels)


def first_clustering(num_clusters, train_features):
    # clustering for features
    print('start clustering')
    kmeans = KMeans(n_clusters=num_clusters, random_state=0)
    train_features_np = train_features.numpy().reshape(train_features.size(0), -1)
    cluster_labels = kmeans.fit_predict(train_features_np)
    cluster_centers = kmeans.cluster_centers_
    print('clustering done')
    return cluster_labels, cluster_centers



def saveModel(model, epoch):
    now = datetime.datetime.now()
    time_string = now.strftime("%m%d%H%M")
    PATH = './emb_' + time_string + '_' + str(epoch + 1) + '.pth'
    torch.save(model.state_dict(), PATH)


def main():
    # train_loader, train_loader1 = get_data_loaders1(dataset_name, batch_size, image_size),
    # train_loader, test_loader = get_data_loaders()

    # pretrained model for cluster
    # model1 = EfficientNet.from_pretrained("efficientnet-b0")
    # model = se_resnet20(num_classes=10, reduction=16)
    # model1 = torchvision.models.resnet18(pretrained=True)
    # model1.fc = torch.nn.Identity()
    # model1.eval()

    # train_features, train_labels = extract_features(train_loader, model)
    # # test_features, test_labels = extract_features(testloader, model)
    #
    # # 保存特征向量
    # torch.save(train_features, './data/se_train_features_cifar10.pt')
    # torch.save(train_labels, './data/train_labels_cifar10.pt')

    print("features loaded")
    train_features = torch.load('./data/se_train_features_cifar10.pt')
    import hccl.cluster_config
    cluster_labels, cluster_centers = first_clustering(hccl.cluster_config.num_clusters, train_features)
    # 将聚类标签保存到文件中
    np.savetxt('./data/' + hccl.cluster_config.path_file + hccl.cluster_config.num_clusters.__str__()+'.txt', cluster_labels, fmt='%d')


if __name__ == '__main__':
    main()
