num_clusters = 1000
# cluster_labels_cifar10_
# cluster_se_labels_cifar10_
path_file = 'cluster_se_labels_cifar10_'