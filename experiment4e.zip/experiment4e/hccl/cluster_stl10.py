import os
import matplotlib
from sklearn.cluster import KMeans
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
import torchvision
import torch.multiprocessing
import datetime
from torch.optim import RMSprop
import numpy as np
import hccl.stl10.a_train_stl10_net,hccl.stl10.a_train_stl10_config,hccl.stl10.a_train_stl10_loaddata

torch.multiprocessing.set_sharing_strategy('file_system')
matplotlib.use('Agg')


# get features
def extract_features(train_data, model, DEVICE):
    features = []
    labels = []
    # model.eval()
    with torch.no_grad():
        for batch,(imgL,imgR,labels) in enumerate(train_data):
            imgL, imgR, labels = imgL.to(DEVICE), imgR.to(DEVICE), labels.to(DEVICE)
            features.append(model(imgL).to(DEVICE))
            labels.append(labels)
    print('extract_features done')
    return torch.cat(features), torch.cat(labels)


def first_clustering(num_clusters, train_features):
    # clustering for features
    print('start clustering')
    kmeans = KMeans(n_clusters=num_clusters, random_state=0)
    train_features_np = train_features.numpy().reshape(train_features.size(0), -1)
    cluster_labels = kmeans.fit_predict(train_features_np)
    cluster_centers = kmeans.cluster_centers_
    print('clustering done')
    return cluster_labels, cluster_centers



def main():
    if torch.cuda.is_available() and hccl.stl10.a_train_stl10_config.use_gpu:
        DEVICE = torch.device("cuda:" + str(hccl.stl10.a_train_stl10_config.gpu_name))
        # 每次训练计算图改动较小使用，在开始前选取较优的基础算法（比如选择一种当前高效的卷积算法）
        torch.backends.cudnn.benchmark = True
    else:
        DEVICE = torch.device("cpu")
    print("current deveice:", DEVICE)

    # train_loader, train_loader1 = get_data_loaders1(dataset_name, batch_size, image_size),
    train_dataset = hccl.stl10.a_train_stl10_loaddata.PreDataset(root='./data', split = 'train',
                                                                 transform=hccl.stl10.a_train_stl10_config.train_transform,
                                                                 download=True)
    train_data = torch.utils.data.DataLoader(train_dataset, batch_size=256, shuffle=True, num_workers=16,
                                             drop_last=True)

    # pretrained model for cluster
    # model1 = EfficientNet.from_pretrained("efficientnet-b0")
    model1 = torchvision.models.resnet18(pretrained=True)
    model1.fc = torch.nn.Identity()
    model1.eval()

    train_features, train_labels = extract_features(train_data, model1, DEVICE)
    # test_features, test_labels = extract_features(testloader, model)

    # 保存特征向量
    torch.save(train_features, './data/train_features_stl10.pt')
    torch.save(train_labels, './data/train_labels_stl10.pt')

    print("features loaded")
    # train_features = torch.load('./data/train_features_cifar10.pt')

    num_clusters = 10
    cluster_labels, cluster_centers = first_clustering(num_clusters, train_features)
    # 将聚类标签保存到文件中
    np.savetxt('./data/cluster_labels_stl10_' + num_clusters.__str__() + '.txt', cluster_labels, fmt='%d')


if __name__ == '__main__':
    main()
