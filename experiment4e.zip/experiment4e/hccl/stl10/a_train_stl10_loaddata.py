# loaddataset.py
from torchvision.datasets import STL10
from PIL import Image
import numpy as np


class PreDataset(STL10):
    def __getitem__(self, item):
        img,target=self.data[item],self.labels[item]
        img = np.transpose(img, (1, 2, 0))
        img = Image.fromarray(img)

        if self.transform is not None:
            imgL = self.transform(img)
            imgR = self.transform(img)

        if self.target_transform is not None:
            target = self.target_transform(target)

        return imgL, imgR, target


if __name__=="__main__":
    import hccl.stl10.a_train_stl10_config
    train_data = PreDataset(root='../data', split = 'train', transform=hccl.stl10.a_train_stl10_config.train_transform, download=True)
    print(train_data[0])
